package com.poc.retry.service;

public class CustomException extends Exception{

}
