package com.poc.retry.service;

import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;


@Service
public class TestService {
	
  int i=0;

  @Retryable(maxAttempts = 5, value={CustomException.class}, backoff = @Backoff(delay = 5000))
  public int call() throws CustomException {
	System.out.println("Calling...");
    if (i < 10) {
      i++;
      throw new CustomException();
    }
    System.out.println("Success");
    return 1;
  }


  @Recover
  private int fallback() {
    System.out.println("Fallback Method");
    return 0;
  }
}
