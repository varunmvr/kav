package com.poc.retry.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.retry.service.CustomException;
import com.poc.retry.service.TestService;

@RestController
public class TestController {

  @Autowired
  private TestService service;

  @GetMapping("/test")
  public int test() throws CustomException{
    return service.call();
  }
}
